package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = AmberOrange,
    secondary = EmeraldGreen,
    tertiary = SlateGray,
    background = DeepSlateBlue,
    surface = SlateCard,
    onBackground = OffWhite,
    onSurface = OffWhite,
    primaryContainer = SlateCard,
    onPrimaryContainer = OffWhite
  )

private val LightColorScheme = DarkColorScheme // Always premium dark mode!

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark mode
  dynamicColor: Boolean = false, // Force brand colors
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
